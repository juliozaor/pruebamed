<div class="d-flex">
  <div class="form-floating me-2 w-50">
    <textarea class="form-control m-2" placeholder="Leave a comment here" id="motivoConsulta" style="height: 100px"></textarea>
    <label for="motivoConsulta">MOTIVO DE CONSULTA</label>
  </div>

  <div class="form-floating ms-2 w-50">
    <textarea class="form-control m-2" placeholder="Leave a comment here" id="motivoConsultaTranscripcion" style="height: 100px"></textarea>
    <label for="motivoConsultaTranscripcion">TRANSCRIPCIÓN SINTOMATOLOGIA (Procesa motivo)</label>
  </div>

</div>
<div class="d-flex">
<div class="form-floating me-2 w-50">
  <textarea class="form-control m-2" placeholder="Leave a comment here" id="enfermedadActual" style="height: 100px"></textarea>
  <label for="enfermedadActual">ENFERMEDAD ACTUAL</label>
</div>

<div class="form-floating ms-2 w-50">
  <textarea class="form-control m-2" placeholder="Leave a comment here" id="enfermedadActualTranscipcion" style="height: 100px"></textarea>
  <label for="enfermedadActualTranscipcion">TRANSCRIPCIÓN SINTOMATOLOGIA (procesa enfermedad)</label>
</div>

</div>