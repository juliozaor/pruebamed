<div class="form-floating">
          <textarea class="form-control m-2" placeholder="Leave a comment here" id="signosVitales" style="height: 100px"></textarea>
          <label for="signosVitales">SIGNOS VITALES</label>
        </div>

        <div class="form-floating">
          <textarea class="form-control m-2" placeholder="Leave a comment here" id="presionSitolica" style="height: 100px"></textarea>
          <label for="presionSitolica">PRESION ARTERIAL SISTOLICA</label>
        </div>

        <div class="form-floating">
          <textarea class="form-control m-2" placeholder="Leave a comment here" id="presionDiastolica" style="height: 100px"></textarea>
          <label for="presionDiastolica">PRESION ARTERIAL DIASTOLICA</label>
        </div>